# Lost & Found Portal (MERN)

A campus lost-and-found web application built with MongoDB, Express, React and Node.js.

## Features
- Browse lost and found reports
- Search and filter by type/category
- Submit a lost or found item with image URL and contact details
- View item details
- Mark an item as claimed/returned
- Responsive layout

## Requirements
- Node.js 18+
- MongoDB local installation or MongoDB Atlas connection string

## Setup

### 1. Backend
```bash
cd server
cp .env.example .env
# Set MONGO_URI and PORT in .env
npm install
npm run dev
```
Backend runs at `http://localhost:5000`.

### 2. Frontend
Open another terminal:
```bash
cd client
npm install
npm run dev
```
Frontend runs at `http://localhost:5173`.

The Vite development server proxies `/api` requests to the backend.

## Notes
- This is a student project starter. For production, add authentication, input validation, image uploads, rate limiting and moderation.
- Image field accepts a publicly accessible image URL.
