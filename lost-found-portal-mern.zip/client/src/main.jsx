import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, Plus, MapPin, CalendarDays, ArrowUpRight, PackageSearch, CheckCircle2, X, ShieldCheck } from 'lucide-react';
import './styles.css';

const API = '/api';
const fallbackItems = [
  { _id: 'sample1', title: 'Black wireless headphones', type: 'Lost', category: 'Electronics', location: 'Library, 2nd floor', date: '2026-11-21', description: 'Black over-ear headphones left near the study tables.', contactName: 'Student', contact: 'Please add your contact after connecting MongoDB.', status: 'Open', imageUrl: '' },
  { _id: 'sample2', title: 'Blue water bottle', type: 'Found', category: 'Personal items', location: 'Cafeteria entrance', date: '2026-11-22', description: 'A blue bottle was found beside the entrance.', contactName: 'Student', contact: 'Please add your contact after connecting MongoDB.', status: 'Open', imageUrl: '' },
  { _id: 'sample3', title: 'College ID card', type: 'Lost', category: 'ID & cards', location: 'Main block', date: '2026-11-23', description: 'College ID card. Please contact me if you find it.', contactName: 'Student', contact: 'Please add your contact after connecting MongoDB.', status: 'Open', imageUrl: '' }
];

function App() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [modal, setModal] = useState(false);
  const [selected, setSelected] = useState(null);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ title:'', type:'Lost', category:'Other', location:'', date:new Date().toISOString().slice(0,10), description:'', imageUrl:'', contactName:'', contact:'' });

  async function loadItems() {
    try {
      const res = await fetch(`${API}/items`);
      if (!res.ok) throw new Error();
      setItems(await res.json());
    } catch { setItems(fallbackItems); }
  }
  useEffect(() => { loadItems(); }, []);

  const filtered = useMemo(() => items.filter(item =>
    (filter === 'All' || item.type === filter) &&
    `${item.title} ${item.description} ${item.location} ${item.category}`.toLowerCase().includes(search.toLowerCase())
  ), [items, filter, search]);

  async function submitItem(e) {
    e.preventDefault();
    try {
      const res = await fetch(`${API}/items`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      if (!res.ok) throw new Error('Backend not connected');
      const item = await res.json();
      setItems(prev => [item, ...prev]); setModal(false); setNotice('Your report has been published.');
      setForm({ title:'', type:'Lost', category:'Other', location:'', date:new Date().toISOString().slice(0,10), description:'', imageUrl:'', contactName:'', contact:'' });
    } catch { setNotice('Connect the backend to MongoDB to publish reports.'); }
  }

  async function updateStatus(item, status) {
    try {
      const res = await fetch(`${API}/items/${item._id}/status`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({status}) });
      if (!res.ok) throw new Error();
      const updated = await res.json();
      setItems(prev => prev.map(x => x._id === updated._id ? updated : x));
      setSelected(updated); setNotice(`Item marked ${status.toLowerCase()}.`);
    } catch { setNotice('Status updates need the backend and database running.'); }
  }

  return <div className="app">
    <nav className="nav">
      <a className="brand" href="#"><span className="brand-icon"><PackageSearch size={22}/></span><span>Campus<span className="brand-accent">Find</span><small>LOST & FOUND PORTAL</small></span></a>
      <div className="nav-right"><span className="nav-link"><ShieldCheck size={16}/> Campus community</span><button className="primary small" onClick={() => setModal(true)}><Plus size={17}/> Report an item</button></div>
    </nav>
    <main>
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><span className="dot"/> YOUR CAMPUS, CONNECTED</div><h1>Lost something?<br/><em>Find it here.</em></h1><p>A little help from your campus community can bring your lost belongings back home.</p>
          <div className="hero-actions"><button className="primary" onClick={() => {setForm(f=>({...f,type:'Lost'}));setModal(true)}}><Search size={18}/> I lost something</button><button className="secondary" onClick={() => {setForm(f=>({...f,type:'Found'}));setModal(true)}}><Plus size={18}/> I found something</button></div>
          <div className="trust"><span><CheckCircle2 size={16}/> Simple to report</span><span><CheckCircle2 size={16}/> Built for campus</span></div></div>
        <div className="hero-art"><div className="art-circle"></div><div className="art-card card-back"><div className="mini-label">FOUND ITEM</div><div className="mini-item"><span className="bottle">◒</span><div><b>Water bottle</b><small>Student center</small></div></div></div><div className="art-card card-front"><div className="art-top"><span className="art-tag">RECENTLY LOST</span><span className="art-check"><CheckCircle2 size={18}/></span></div><div className="headphones">◉</div><b>Headphones</b><small>Library · Yesterday</small><div className="art-line"></div><div className="art-foot"><span>Let's reunite</span><ArrowUpRight size={16}/></div></div><div className="spark spark-one">✦</div><div className="spark spark-two">✧</div></div>
      </section>
      <section className="board">
        <div className="section-head"><div><div className="eyebrow muted">COMMUNITY BOARD</div><h2>Recently reported</h2><p>Browse items reported by students around campus.</p></div><div className="count"><b>{filtered.length}</b><span>reports</span></div></div>
        <div className="toolbar"><div className="searchbox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search items, locations..."/></div><div className="filters">{['All','Lost','Found'].map(x=><button key={x} className={filter===x?'active':''} onClick={()=>setFilter(x)}>{x}</button>)}</div></div>
        {notice && <div className="notice" role="status">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
        <div className="items-grid">{filtered.map(item=><article className="item-card" key={item._id} onClick={()=>setSelected(item)}><div className={`item-visual ${item.type.toLowerCase()}`}>{item.imageUrl ? <img src={item.imageUrl} alt={item.title}/> : <div className="visual-symbol">{item.type==='Lost'?'⌕':'✧'}</div>}<span className={`type-pill ${item.type.toLowerCase()}`}>{item.type}</span></div><div className="item-content"><div className="item-meta"><span>{item.category}</span><span className={item.status==='Open'?'status-open':'status-done'}>{item.status}</span></div><h3>{item.title}</h3><p className="item-desc">{item.description}</p><div className="item-info"><span><MapPin size={14}/>{item.location}</span><span><CalendarDays size={14}/>{new Date(item.date).toLocaleDateString()}</span></div><button className="view-link">View details <ArrowUpRight size={15}/></button></div></article>)}</div>
        {filtered.length===0 && <div className="empty"><PackageSearch size={35}/><h3>No reports found</h3><p>Try another search or be the first to report an item.</p><button className="primary" onClick={()=>setModal(true)}><Plus size={16}/> Report an item</button></div>}
      </section>
      <section className="bottom-cta"><div><span className="eyebrow">HELP YOUR CAMPUS</span><h2>Found something that isn't yours?</h2><p>Make someone's day. Report it and help it find its owner.</p></div><button className="primary" onClick={()=>{setForm(f=>({...f,type:'Found'}));setModal(true)}}>Report a found item <ArrowUpRight size={17}/></button></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon"><PackageSearch size={19}/></span><span>Campus<span className="brand-accent">Find</span></span></a><span>Made for a more helpful campus community.</span><span>© 2026 CampusFind</span></footer>
    {modal && <div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setModal(false)}><div className="modal"><div className="modal-head"><div><span className="eyebrow muted">COMMUNITY REPORT</span><h2>Report an item</h2><p>Share a few details to help reunite it with its owner.</p></div><button className="close" onClick={()=>setModal(false)}><X/></button></div><form onSubmit={submitItem}><div className="form-row"><label>Report type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Lost</option><option>Found</option></select></label><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{['Other','Electronics','ID & cards','Books & stationery','Clothing','Personal items','Keys'].map(c=><option key={c}>{c}</option>)}</select></label></div><label>Item name<input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Black headphones"/></label><label>Description<textarea required value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe the item..." rows="3"/></label><div className="form-row"><label>Location<input required value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="Where was it lost/found?"/></label><label>Date<input type="date" required value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></label></div><label>Image URL <span className="optional">(optional)</span><input value={form.imageUrl} onChange={e=>setForm({...form,imageUrl:e.target.value})} placeholder="https://..."/></label><div className="form-row"><label>Your name<input required value={form.contactName} onChange={e=>setForm({...form,contactName:e.target.value})} placeholder="Name"/></label><label>Contact details<input required value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="Email or phone"/></label></div><button className="primary submit" type="submit">Publish report <ArrowUpRight size={17}/></button></form></div></div>}
    {selected && <div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setSelected(null)}><div className="modal details"><button className="close detail-close" onClick={()=>setSelected(null)}><X/></button><span className={`type-pill ${selected.type.toLowerCase()}`}>{selected.type} item</span><h2>{selected.title}</h2><p>{selected.description}</p><div className="detail-list"><span><MapPin size={16}/>{selected.location}</span><span><CalendarDays size={16}/>{new Date(selected.date).toLocaleDateString()}</span><span><b>Category:</b> {selected.category}</span><span><b>Reported by:</b> {selected.contactName}</span><span><b>Contact:</b> {selected.contact}</span><span><b>Status:</b> {selected.status}</span></div>{selected.status==='Open' && <div className="detail-actions"><button className="secondary" onClick={()=>updateStatus(selected,'Claimed')}>Mark claimed</button><button className="primary" onClick={()=>updateStatus(selected,'Returned')}>Mark returned <CheckCircle2 size={16}/></button></div>}</div></div>}
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
