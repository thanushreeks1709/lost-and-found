import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const itemSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  type: { type: String, enum: ['Lost', 'Found'], required: true },
  category: { type: String, default: 'Other' },
  location: { type: String, required: true },
  date: { type: Date, default: Date.now },
  imageUrl: { type: String, default: '' },
  contactName: { type: String, required: true },
  contact: { type: String, required: true },
  status: { type: String, enum: ['Open', 'Claimed', 'Returned'], default: 'Open' }
}, { timestamps: true });

const Item = mongoose.model('Item', itemSchema);

app.get('/api/health', (_req, res) => res.json({ status: 'ok', message: 'Lost & Found API is running' }));

app.get('/api/items', async (req, res) => {
  try {
    const { type, search, status } = req.query;
    const filter = {};
    if (type && type !== 'All') filter.type = type;
    if (status) filter.status = status;
    if (search) filter.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
      { location: { $regex: search, $options: 'i' } },
      { category: { $regex: search, $options: 'i' } }
    ];
    const items = await Item.find(filter).sort({ createdAt: -1 });
    res.json(items);
  } catch (err) { res.status(500).json({ message: 'Could not load items' }); }
});

app.get('/api/items/:id', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch { res.status(400).json({ message: 'Invalid item ID' }); }
});

app.post('/api/items', async (req, res) => {
  try {
    const item = await Item.create(req.body);
    res.status(201).json(item);
  } catch (err) { res.status(400).json({ message: err.message || 'Invalid item details' }); }
});

app.patch('/api/items/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['Open', 'Claimed', 'Returned'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
    const item = await Item.findByIdAndUpdate(req.params.id, { status }, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch { res.status(400).json({ message: 'Could not update status' }); }
});

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/lost_found_portal')
  .then(() => app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`)))
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
